function input(char) {
    document.getElementById('result').value += char;
}

// Função para excluir o último caractere da entrada
function del() {
    var result = document.getElementById('result').value;
    document.getElementById('result').value = result.substring(0, result.length - 1);
}

// Função para limpar a entrada
function reset() {
    document.getElementById('result').value = '';
}

// Função para calcular a expressão
function calc() {
    var result = document.getElementById('result').value;
    try {
        var answer = eval(result);
        document.getElementById('result').value = answer;
    } catch (error) {
        alert('Expressão inválida!');
    }
}

// Função para calcular a porcentagem
function percentage() {
    var result = document.getElementById('result').value;
    try {
        var answer = eval(result) / 100;
        document.getElementById('result').value = answer;
    } catch (error) {
        alert('Expressão inválida!');
    }
}

// Funções para operações matemáticas básicas
function add() {
    var result = document.getElementById('result').value;
    document.getElementById('result').value = eval(result) + '+';
}

function subtract() {
    var result = document.getElementById('result').value;
    document.getElementById('result').value = eval(result) + '-';
}

function multiply() {
    var result = document.getElementById('result').value;
    document.getElementById('result').value = eval(result) + '*';
}

function divide() {
    var result = document.getElementById('result').value;
    document.getElementById('result').value = eval(result) + '/';
}

function power() {
    var result = document.getElementById('result').value;
    document.getElementById('result').value = eval(result) + '**';
}

function squareRoot() {
    var result = document.getElementById('result').value;
    document.getElementById('result').value = 'Math.sqrt(' + result + ')';
}